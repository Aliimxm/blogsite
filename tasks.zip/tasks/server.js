const express = require("express");
const app = express();

app.use(express.static("public"));
app.use(express.urlencoded({extended:true}))
app.set("view engine","ejs");

app.listen(8000, () => {
  console.log("Started Listening on port 8000");
});

var tasks=[];
app.get("/", (req, res) => {
  res.render("task", { tasks: tasks });
});
app.get("/add",(req,res)=>{
    res.sendFile(__dirname+"/index.html")
})
app.post("/add",(req,res)=>{
    const date=new Date();
    
    var object={
        taskName:req.body.taskName,
        taskDes:req.body.taskDes,
        date:date
    }
    tasks.push(object);
    res.redirect("/");
})